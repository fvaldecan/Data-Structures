For execution:
--------------
1. $ make Lab09
2. $ ./Lab09 (file name)
	- if file name not inputed, it will automatically use in.txt

