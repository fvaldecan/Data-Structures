For execution:
--------------
1. $ make Lab08
2. $ ./Lab08 (file name)
	- if file name not inputed, it will automatically use in.txt
